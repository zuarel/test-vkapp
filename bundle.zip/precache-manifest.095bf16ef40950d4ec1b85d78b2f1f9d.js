self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "03295c0d6971cf8ea0a109fa2253ac03",
    "url": "./index.html"
  },
  {
    "revision": "cca8db49d9e04f056ede",
    "url": "./static/css/2.2cfa1b23.chunk.css"
  },
  {
    "revision": "c6129966772f5139d189",
    "url": "./static/css/main.101f4230.chunk.css"
  },
  {
    "revision": "cca8db49d9e04f056ede",
    "url": "./static/js/2.74b84489.chunk.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "./static/js/2.74b84489.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c6129966772f5139d189",
    "url": "./static/js/main.86687419.chunk.js"
  },
  {
    "revision": "170fa7990bb91501cdd1",
    "url": "./static/js/runtime-main.97bb9156.js"
  },
  {
    "revision": "6cae0655902fa5ee9c891d4e5cf4e8af",
    "url": "./static/media/Manrope_bold.6cae0655.woff"
  },
  {
    "revision": "9d3d7c29198c456aaad387a1b03dc4ee",
    "url": "./static/media/Manrope_bold.9d3d7c29.ttf"
  },
  {
    "revision": "83b35526cd725870d5e8e4c57c1f053e",
    "url": "./static/media/Manrope_medium.83b35526.ttf"
  },
  {
    "revision": "cb77783d8b06354f0fedb61024569259",
    "url": "./static/media/Manrope_medium.cb77783d.woff"
  },
  {
    "revision": "2640802b08e8f37e557305e1c116ccd4",
    "url": "./static/media/Manrope_regular.2640802b.ttf"
  },
  {
    "revision": "d028b9e3c6091e42f04080297f301513",
    "url": "./static/media/Manrope_regular.d028b9e3.woff"
  },
  {
    "revision": "55b6636cf0bfc6175d715309dd8dcc61",
    "url": "./static/media/Manrope_semibold.55b6636c.ttf"
  },
  {
    "revision": "a861384a9720dcb8ad97ee26a90855e0",
    "url": "./static/media/Manrope_semibold.a861384a.woff"
  },
  {
    "revision": "9706eefa6a2562116cced5f4b6e2b7d5",
    "url": "./static/media/vkapp-bg.9706eefa.png"
  }
]);